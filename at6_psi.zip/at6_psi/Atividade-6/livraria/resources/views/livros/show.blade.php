ID:{{$livro->id_livro}}<br>
Titulo:{{$livro->titulo}}<br>
Idioma:{{$livro->idioma}}<br>
<a href="{{route('livros.edit', ['id'=>$livro->id_livro])}}">Editar</a>
<a href="{{route('livros.delete', ['id'=>$livro->id_livro])}}">Eliminar</a>
