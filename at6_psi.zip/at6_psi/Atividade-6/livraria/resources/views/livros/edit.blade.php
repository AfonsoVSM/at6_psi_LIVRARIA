<form action="" method="post">

@csrf
@method('patch')
Tilulo: <input type="text" name="titulo" value="{{$livro->titulo}}"><br>>
@if ( $errors->has('titulo') )
Devera indicar um titulo valido<br>
@endif
Idioma: <input type="text" name="idioma" value=""><br>

Total paginas: <input type="text" name="total_paginas" value=""><br>

ISBN: <input type="text" name=""><br>

@if ( $errors->has('isbn') )
Devera indicar um isbn correto (13carateres)<br>
@endif

Observaçoes: <textarea> name="obsevaçoes"</textarea><br>