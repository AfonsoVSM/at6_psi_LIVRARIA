<form action="{{route('autores.store')}}" method="post">
@csrf
Nome: <input type="text" name="nome"><br><br>
@if ($errors->has('nome'))<br><br>
Devera indicar um nome correto (4 carateres)
@endif
Nacionalidade: <input type="text" name="nacionalidade"><br><br>
@if ($errors->has('nacionalidade'))<br><br>
Devera indicar uma morada correta (13 carateres)
@endif
Data de Nascimento: <input type="text" name="data_nascimento"><br><br>
@if ($errors->has('observacoes'))<br><br>
Devera indicar uma data de nascimento correta (4 carateres)
@endif
Fotografia: <input type="text" name="fotografia"><br><br>
@if ($errors->has('fotografia'))<br><br>
Devera indicar uma fotografia correto (4 carateres)
@endif

<input type="submit" value="Enviar">
</form>
