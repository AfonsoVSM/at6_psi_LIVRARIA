ID:{{$autor->id_autor}}<br>
Nome:{{$autor->nome}}<br>
nacionalidade:{{$autor->nacionalidade}}
