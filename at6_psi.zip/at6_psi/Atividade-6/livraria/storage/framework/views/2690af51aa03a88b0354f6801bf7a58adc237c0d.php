ID:<?php echo e($genero->idg); ?><br>
Desinação:<?php echo e($genero->designacao); ?><br>
Observações:<?php echo e($genero->observacoes); ?><?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>